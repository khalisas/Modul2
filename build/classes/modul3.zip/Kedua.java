
package modul3;

public class Kedua extends Pertama{
    private int b = 8;
    protected void BacaSuper(){
        System.out.println("Nilai b:"+b);
        terpotek();
        info();
    }
    
}
