
package modul3;

public class A {
    private int a;
    public void setA (int nilai){
        a = nilai;
    }
    
    public int getA(){
        return a;
    }
    
    public void tampilkanNilai(){
        System.out.println("Nilai a:"+getA());
    } 
    
}
