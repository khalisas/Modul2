package modul3;

public class KonstruktorSiswaTelkom {
    public static void main (String [] args){
        Murid mbo = new Murid("Shiva", 16,"SMK TELKOM MALANG");
        
        mbo.info();
        
    }
    
}
