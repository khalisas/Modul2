
package modul3;

public class TestPertamaKedua {
    public static void main (String [] args){
        Kedua D2 = new Kedua();
        D2.BacaSuper();
        D2.info();
        
        Pertama S1 = new Pertama ();
        S1.info();
        
    }
    
}
