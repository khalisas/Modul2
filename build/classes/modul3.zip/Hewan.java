
package modul3;

public class Hewan {
    public static void testClassMethod(){
        System.out.println("The Class Method in Hewan ...");
    }
    public void testInstanceMethod(){
        System.out.println("The Instance Method in Hewan ... ");
    }
    
}
