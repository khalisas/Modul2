
package modul3;

public class KonstruktorSuperKelas {
    public static void main (String [] args){
        Employ programmer1 = new Employ ("12345678", "Yanto", 32);
        programmer1.info();
         
    }
    
}   


